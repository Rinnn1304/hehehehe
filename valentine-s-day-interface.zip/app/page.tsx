import { ValentineApp } from "@/components/valentine-app"

export default function Page() {
  return <ValentineApp />
}
